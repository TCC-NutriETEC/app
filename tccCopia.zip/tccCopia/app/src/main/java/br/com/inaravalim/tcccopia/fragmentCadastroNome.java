package br.com.inaravalim.tcccopia;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/**
 * A simple {@link Fragment} subclass.
 */
public class fragmentCadastroNome extends Fragment {

    FloatingActionButton btnnome;
    EditText editnomecad;
    IrecebeDados mListener;//Comunicaçao entre fragments e activity

    public fragmentCadastroNome() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(Context activity) {
        super.onAttach(activity);
        if (!(activity instanceof IrecebeDados)) {
            throw new RuntimeException("A activity deve implementar a iinterface");
        }
        mListener = (IrecebeDados) activity;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_cadastro_nome, container, false);
        editnomecad = (EditText) v.findViewById(R.id.editnomecad);
        btnnome = (FloatingActionButton) v.findViewById(R.id.btnproximonome);

        btnnome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nome = editnomecad.getText().toString();
                if (!(nome.isEmpty())) {

                    mListener.onNome(nome);

                    ///ABRIR PROXIMO FRAGEMENT
                    FragmentManager fm = getFragmentManager();
                    FragmentTransaction ft = fm.beginTransaction();
                    ft.setCustomAnimations(R.anim.slide_in_right, R.anim.slide_in_right);
                    ft.replace(R.id.fragmentos, new fragmentCadastroPeso());
                    ft.addToBackStack(null);
                    ft.commit();

                } else {
                    editnomecad.setError("O campo está em branco");
                    //Toast.makeText(getActivity().getApplicationContext(), "O campo está em branco ", Toast.LENGTH_LONG).show();
                }
            }
        });//FIM METODO CLIQUE PROXIMO
        return (v);
    }
}