package br.com.inaravalim.tcccopia;

import android.animation.ObjectAnimator;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;

import java.util.ArrayList;

public class MainPesquisar extends AppCompatActivity {
    private String prefalimento = "alimento";
    private TextView txtrefeicao;
    private EditText editpesquisaalimento;
    private ImageButton pesquisar;
    private FrameLayout layoutEdit, layoutLista;
    private int user=0;
    private String HOST = "https://tccnutriinfo.000webhostapp.com";
    private ArrayList<Alimento> list;
    private alimentoAdapter alimentoAdapter;
    private ListView lista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_pesquisar);
        getSupportActionBar().hide();//nao aparecer menu
        txtrefeicao = (TextView) findViewById(R.id.txtrefeicao);
        lista = (ListView) findViewById(R.id.listaalimentos);
        editpesquisaalimento = (EditText) findViewById(R.id.pesquisaalimento);
        pesquisar = (ImageButton) findViewById(R.id.pesquisar);
        layoutEdit = (FrameLayout) findViewById(R.id.layout);
        layoutLista = (FrameLayout) findViewById(R.id.layoutlista);
        list = new ArrayList<Alimento>();
        alimentoAdapter = new alimentoAdapter(this, list);
        lista.setAdapter(alimentoAdapter);
        pesquisar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String alimento = editpesquisaalimento.getText().toString();
                if (!(alimento.isEmpty())){
                    if (user==0){
                        animacao();
                        adicionarAlimento(alimento);
                        user=1;
                    }else{
                        adicionarAlimento(alimento);
                    }
                    lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                            String nome_alimento = list.get(i).getNomeAlimento();
                            SharedPreferences preferences = getSharedPreferences(prefalimento, MODE_PRIVATE);
                            SharedPreferences.Editor editor = preferences.edit();
                            editor.putString("NOME_ALIMENTO",nome_alimento);
                            editor.commit();
                            Intent intent = new Intent(MainPesquisar.this, Insere.class);
                            startActivity(intent);
                            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                        }
                    });
                }
            }
        });
    }

    private void adicionarAlimento(String alimento) {
        String url = HOST + "/pesquisaalimento.php";
        Ion.with(MainPesquisar.this)
                .load(url)
                .setBodyParameter("alimento",alimento)
                .asJsonArray()
                .setCallback(new FutureCallback<JsonArray>() {
                    @Override
                    public void onCompleted(Exception e, JsonArray result) {
                        for (int i = 0; i < result.size(); i++) {
                            JsonObject obj = result.get(i).getAsJsonObject();
                            Alimento d = new Alimento();
                            d.setNomeAlimento(obj.get("NOME_ALIMENTO").getAsString());
                            list.add(d);
                        }
                        alimentoAdapter.notifyDataSetChanged();
                    }
                });
    }

    private void animacao() {
        Animation desloca = new TranslateAnimation(0, 0, 0, -380);
        desloca.setFillAfter(true);
        desloca.setDuration(1000);
        layoutEdit.startAnimation(desloca);
        layoutLista.setVisibility(View.VISIBLE);
        ObjectAnimator anim = ObjectAnimator.ofFloat(layoutLista, "alpha", 0f, 1f);
        anim.setDuration(4000);
        anim.start();
    }

    @Override
    public void onResume() {
        super.onResume();
        atualizarRefeicao();
    }

    private void atualizarRefeicao() {
        SharedPreferences preferences = getSharedPreferences(prefalimento, MODE_PRIVATE);
        String refeicao = preferences.getString("REFEICAO", "vazio");
        txtrefeicao.setText(refeicao);
    }
}
