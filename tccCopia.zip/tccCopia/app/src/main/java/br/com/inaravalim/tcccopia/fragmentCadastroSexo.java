package br.com.inaravalim.tcccopia;

import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

/**
 * A simple {@link Fragment} subclass.
 */
public class fragmentCadastroSexo extends Fragment {

    private FloatingActionButton btnsexo;
    private RadioGroup grupobotao;
    private RadioButton radiofem, radiomasc;
    IrecebeDados mListener;//Comunicaçao entre fragments e activity

    public fragmentCadastroSexo() {
    }

    @Override
    public void onAttach(Context activity) {
        super.onAttach(activity);
        if (!(activity instanceof IrecebeDados)) {
            throw new RuntimeException("A activity deve implementar a iinterface");
        }
        mListener = (IrecebeDados) activity;
        //esse obj se torna o meio de comunicaçao
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_cadastro_sexo, container, false);
        radiofem = (RadioButton) v.findViewById(R.id.btnfem);
        radiomasc = (RadioButton) v.findViewById(R.id.btnmas);
        btnsexo = (FloatingActionButton) v.findViewById(R.id.btnproximosexo);



        btnsexo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!(radiofem.isChecked() || radiomasc.isChecked())) {
                    Toast.makeText(getActivity().getApplicationContext(), "Selecione o sexo ", Toast.LENGTH_LONG).show();
                } else {
                    if (radiofem.isChecked()) {
                        mListener.onSexo(1);
                    } else {
                        mListener.onSexo(2);
                    }
                    ///ABRIR PROXIMO FRAGEMENT
                    FragmentManager fm = getFragmentManager();
                    FragmentTransaction ft = fm.beginTransaction();
                    ft.replace(R.id.fragmentos, new fragmentCadastroData());
                    ft.addToBackStack(null);
                    ft.commit();
                }
            }
        });
        return (v);
    }
}
