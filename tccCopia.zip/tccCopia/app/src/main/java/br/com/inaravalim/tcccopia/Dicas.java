package br.com.inaravalim.tcccopia;

public class Dicas {
    private String conteudo, indice;

   // public Sites(String nome, String link, String conteudo) {
     //   this.nome = nome;
       // this.link = link;
       // this.conteudo = conteudo;
    //}

    public String getIndice() {
        return indice;
    }

    public void setIndice(String indice) {
        this.indice = indice;
    }

    public String getConteudo() {
        return conteudo;
    }

    public void setConteudo(String conteudo) {
        this.conteudo = conteudo;
    }
}
