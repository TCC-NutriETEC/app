package br.com.inaravalim.tcccopia;

public interface IrecebeDados {
    public void onNome(String texto);
    public void onPeso(float texto);
    public void onData(int ano, int mes, int dia, int idade);
    public void onAltura(int texto);
    public void onSexo(int texto);
    public void onEmailonSenha(String emailL, String senhaL);
}
