package br.com.inaravalim.tcccopia;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ProgressBar;
import com.google.gson.JsonObject;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;

public class SplashReceberDados extends AppCompatActivity {
    protected static final int TIMER_RUNTIME = 10000;
    protected ProgressBar mProgressBar;
    protected Boolean mbActive;
    private String pref = "preferencia";
    private String HOST = "https://tccnutriinfo.000webhostapp.com";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_receber_dados);
        mProgressBar = (ProgressBar) findViewById(R.id.barrinha);
        SharedPreferences preferences = getSharedPreferences(pref, MODE_PRIVATE);
        String email = preferences.getString("EMAIL", "vazio");
        String url = HOST + "/dadosusuarios.php";
        //RECEBER DADOS
        Ion.with(SplashReceberDados.this)
                .load(url)
                .setBodyParameter("email", email)
                .asJsonObject()
                .setCallback(new FutureCallback<JsonObject>() {
                    @Override
                    public void onCompleted(Exception e, JsonObject result) {
                        String nome = result.get("NOME").getAsString();
                        String senha = result.get("SENHA").getAsString();
                        float peso = result.get("PESO").getAsFloat();
                        int altura = result.get("ALTURA").getAsInt();
                        String data_nascimento = result.get("DATANASC").getAsString();
                        float caloria = result.get("CALORIA").getAsFloat();
                        float proteina = result.get("PROTEINA").getAsFloat();
                        float carboidrato = result.get("CARBOIDRATO").getAsFloat();
                        int id = result.get("ID").getAsInt();
                        int sexo=result.get("SEXO").getAsInt();
                        SharedPreferences preferences = getSharedPreferences(pref, MODE_PRIVATE);
                        SharedPreferences.Editor editor = preferences.edit();
                        editor.putInt("ID", id);
                        editor.putString("NOME", nome);
                        editor.putFloat("PESO", peso);
                        editor.putInt("ALTURA", altura);
                        editor.putString("DATANASC", data_nascimento);
                        editor.putFloat("CALORIA", caloria);
                        editor.putFloat("PROTEINA", proteina);
                        editor.putFloat("CARBOIDRATO", carboidrato);
                        editor.putString("SENHA", senha);
                        editor.putInt("SEXO", sexo);
                        editor.commit();
                    }
                });
        final Thread timerThread = new Thread() {
            @Override
            public void run() {
                mbActive = true;
                try {
                    int waited = 0;
                    while (mbActive && (waited < TIMER_RUNTIME)) {
                        sleep(200);
                        if (mbActive) {
                            waited += 200;
                            updateProgress(waited);
                        }
                    }
                } catch (InterruptedException e) {
                    //erro
                } finally {
                    onContinue();
                }
            }
        };
        timerThread.start();
    }//on create

    public void updateProgress(final int timePassed) {
        if (null != mProgressBar) {

            final int progress = mProgressBar.getMax() * timePassed / TIMER_RUNTIME;
            mProgressBar.setProgress(progress);
        }
    }

    public void onContinue() {
        Intent intent = new Intent(SplashReceberDados.this, MainPrincipal.class);
        startActivity(intent);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        finish();
    }
}
