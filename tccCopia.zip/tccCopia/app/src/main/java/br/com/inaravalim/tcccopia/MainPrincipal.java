package br.com.inaravalim.tcccopia;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;

import java.util.Calendar;

public class MainPrincipal extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private String pref = "preferencia";
    private TextView txtmeunome, txtmeuemail, txtagua, textoData, txtcalconsumidas,txtcalrestantes, txtcarboidrato,txtproteina;
    private TextView txtcafemanha,txtlanchemanha,txtalmoco,txtlanchetarde,txtjanta,txtlanchenoite;
    private ImageButton btnagua, btncafemanha, btnlanchemanha, btnalmoco, btnlanchetarde, btnjanta, btnlanchenoite;
    private int data, diaAtual, mesCAtual, mesAtual, anoAtual,id;
    private String prefagua = "agua", dataagua,prefalimento="alimento";
    private String HOST = "https://tccnutriinfo.000webhostapp.com";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_principal);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        View headerView = navigationView.getHeaderView(0);
        navigationView.setNavigationItemSelectedListener(this);

        txtcafemanha = (TextView) findViewById(R.id.textocafemanha);
        txtcafemanha = (TextView) findViewById(R.id.textocafemanha);
        txtlanchemanha = (TextView) findViewById(R.id.textolanchemanha);
        txtalmoco = (TextView) findViewById(R.id.textoalmoco);
        txtlanchetarde = (TextView) findViewById(R.id.textolanchetarde);
        txtjanta = (TextView) findViewById(R.id.textojantar);
        txtlanchenoite = (TextView) findViewById(R.id.textolanchenoite);
        textoData = (TextView) findViewById(R.id.textodata);
        txtagua = (TextView) findViewById(R.id.textoagua);
        txtmeunome = (TextView) headerView.findViewById(R.id.meuNome);
        txtmeuemail = (TextView) headerView.findViewById(R.id.meuEmail);
        btnagua = (ImageButton) findViewById(R.id.btnagua);
        btncafemanha = (ImageButton) findViewById(R.id.btncafemanha);
        btnlanchemanha = (ImageButton) findViewById(R.id.btnlanchemanha);
        btnalmoco = (ImageButton) findViewById(R.id.btnalmoco);
        btnlanchetarde = (ImageButton) findViewById(R.id.btnlanchetarde);
        btnjanta = (ImageButton) findViewById(R.id.btnjanta);
        btnlanchenoite = (ImageButton) findViewById(R.id.btnlanchenoite);
        txtcalconsumidas = (TextView) findViewById(R.id.txtcalconsumida);
        txtcalrestantes = (TextView) findViewById(R.id.txtcalrestante);
        txtcarboidrato = (TextView) findViewById(R.id.txtcarboidrato);
        txtproteina = (TextView) findViewById(R.id.txtproteina);

        btnagua.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainPrincipal.this, MainAgua.class);
                startActivity(intent);
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            }
        });
        btncafemanha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                refeicao("Café da manhã",1);
                Intent intent = new Intent(MainPrincipal.this, MainPesquisar.class);
                startActivity(intent);
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            }
        });
        btnlanchemanha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                refeicao("Lanche da manhã",2);
                Intent intent = new Intent(MainPrincipal.this, MainPesquisar.class);
                startActivity(intent);
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            }
        });
        btnalmoco.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                refeicao("Almoço",3);
                Intent intent = new Intent(MainPrincipal.this, MainPesquisar.class);
                startActivity(intent);
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            }
        });
        btnlanchetarde.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                refeicao("Lanche da tarde",4);
                Intent intent = new Intent(MainPrincipal.this, MainPesquisar.class);
                startActivity(intent);
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            }
        });
        btnjanta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                refeicao("Janta",5);
                Intent intent = new Intent(MainPrincipal.this, MainPesquisar.class);
                startActivity(intent);
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            }
        });
        btnlanchenoite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                refeicao("Lanche da noite",6);
                Intent intent = new Intent(MainPrincipal.this, MainPesquisar.class);
                startActivity(intent);
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            }
        });
    }//oncreate

    public void atualizarData() {
        Calendar c = Calendar.getInstance();
        diaAtual = c.get(Calendar.DAY_OF_MONTH);
        mesCAtual = c.get(Calendar.MONTH);
        mesAtual = mesCAtual + 1;
        anoAtual = c.get(Calendar.YEAR);
        if (mesAtual < 10) {
            textoData.setText(new StringBuilder().append(diaAtual).append(" / 0").append(mesAtual).append(" / ").append(anoAtual).toString());
            String mescom0 = new StringBuilder().append("0").append(mesAtual).toString();
            dataagua = new StringBuilder().append(anoAtual).append("-").append(mescom0).append("-").append(diaAtual).toString();
        } else {
            textoData.setText(new StringBuilder().append(diaAtual).append(" / ").append(mesAtual).append(" / ").append(anoAtual).toString());
            dataagua = new StringBuilder().append(anoAtual).append("-").append(mesAtual).append("-").append(diaAtual).toString();
        }
        SharedPreferences preferences = getSharedPreferences(prefagua, MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("DATA", dataagua);
        editor.commit();
        SharedPreferences preferenceusuario = getSharedPreferences(pref, MODE_PRIVATE);
        id = preferenceusuario.getInt("ID", 0);
        atualizaragua(dataagua, id);
        atualizarcalorias(dataagua,id);
    }

    private void atualizaragua(final String dataagua, final int id) {
        String url = HOST + "/readagua.php";
        //RECEBER DADOS
        Ion.with(MainPrincipal.this)
                .load(url)
                .setBodyParameter("dataatual", dataagua)
                .setBodyParameter("idusuario", String.valueOf(id))
                .asJsonObject()
                .setCallback(new FutureCallback<JsonObject>() {
                    @Override
                    public void onCompleted(Exception e, JsonObject result) {
                        int agua = result.get("AGUA").getAsInt();
                        if(agua==0){
                            txtagua.setText("Beba seu primeiro copo de água");
                            SharedPreferences preferences = getSharedPreferences(prefagua, MODE_PRIVATE);
                            SharedPreferences.Editor editor = preferences.edit();
                            editor.putInt("AGUA", agua);
                            editor.commit();
                        }else{
                            txtagua.setText(agua+" ml");
                            SharedPreferences preferences = getSharedPreferences(prefagua, MODE_PRIVATE);
                            SharedPreferences.Editor editor = preferences.edit();
                            editor.putInt("AGUA", agua);
                            editor.commit();
                        }
                    }
                });

    }

    public void sendEmail() {
        String[] TO = {"tcc.etec2018.nutri@gmail.com"};
        String[] CC = {""};

        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setData(Uri.parse("mailto:"));
        emailIntent.putExtra(Intent.EXTRA_EMAIL, TO);
        emailIntent.putExtra(Intent.EXTRA_CC, CC);
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Sugestão");
        emailIntent.putExtra(Intent.EXTRA_TEXT, "Escreva aqui sua sugestão para o aplicativo");
        emailIntent.setType("message/rfc822");
        try {
            startActivity(Intent.createChooser(emailIntent, "Enviar sugestão"));
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(MainPrincipal.this, "Há um erro " + ex, Toast.LENGTH_LONG);
        }
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            this.finishAffinity();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_principal, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.nav_minhaconta) {
            Intent intent = new Intent(MainPrincipal.this, MainUsuario.class);
            startActivity(intent);
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        } else if (id == R.id.nav_sair) {
            SharedPreferences preferences = getSharedPreferences(pref, MODE_PRIVATE);
            SharedPreferences.Editor editor = preferences.edit();
            editor.clear().commit();
            SharedPreferences preference = getSharedPreferences(prefagua, MODE_PRIVATE);
            SharedPreferences.Editor edito = preference.edit();
            edito.clear().commit();
            Intent intent = new Intent(MainPrincipal.this, SplashActivity.class);
            startActivity(intent);
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        } else if (id == R.id.dicas) {
            Intent intent = new Intent(MainPrincipal.this, MainDicas.class);
            startActivity(intent);
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        } else if (id == R.id.sites) {
            Intent intent = new Intent(MainPrincipal.this, MainSites.class);
            startActivity(intent);
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        } else if (id == R.id.nav_nos) {
            Intent intent = new Intent(MainPrincipal.this, MainDesenvolvimento.class);
            startActivity(intent);
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        } else if (id == R.id.nav_sugestao) {
            sendEmail();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onResume() {
        super.onResume();
        SharedPreferences preferences = getSharedPreferences(pref, MODE_PRIVATE);
        String nome = preferences.getString("NOME", "vazio");
        String email = preferences.getString("EMAIL", "vazio");
        txtmeunome.setText(nome);
        txtmeuemail.setText(email);
        atualizarData();
    }

    private void atualizarcalorias(final String dataagua, final int id) {
        String url = HOST + "/caloria.php";
        //RECEBER DADOS
        Ion.with(MainPrincipal.this)
                .load(url)
                .setBodyParameter("dataatual", dataagua)
                .setBodyParameter("idusuario", String.valueOf(id))
                .asJsonObject()
                .setCallback(new FutureCallback<JsonObject>() {
                    @Override
                    public void onCompleted(Exception e, JsonObject result) {
                        int indice = result.get("INDICE").getAsInt();
                        if(indice==1){
                        String caloriaconsumida = result.get("CALORIACON").getAsString();
                        String caloriarestante = result.get("CALORIARESTANTE").getAsString();
                        String proteinacon = result.get("PROTEINACON").getAsString();
                        String carboidratocon = result.get("CARBOIDRATOCON").getAsString();
                        String cafemanha = result.get("CAFEMANHA").getAsString();
                        String lanchemanha = result.get("LANCHEMANHA").getAsString();
                        String almoco = result.get("ALMOCO").getAsString();
                        String lanchetarde = result.get("LANCHETARDE").getAsString();
                        String janta = result.get("JANTA").getAsString();
                        String lanchenoite = result.get("LANCHENOITE").getAsString();
                        atualizarCampos(caloriaconsumida,caloriarestante,proteinacon,carboidratocon, cafemanha,lanchemanha,almoco,lanchetarde,janta,lanchenoite);}
                    }
                });
    }
    private void atualizarCampos(String caloriaconsumida,String caloriarestante,String proteina,String carboidrato, String cafemanha,String lanchemanha,String almoco,String lanchetarde,
                                 String janta,String lanchenoite) {
        txtcalconsumidas.setText(new StringBuilder().append(caloriaconsumida).append(" kcal").toString());
        txtcalrestantes.setText(new StringBuilder().append(caloriarestante).append(" kcal").toString());
        txtproteina.setText(new StringBuilder().append("Proteina: ").append(proteina).append(" g").toString());
        txtcarboidrato.setText(new StringBuilder().append("Carboidrato: ").append(carboidrato).append(" g").toString());
        teste(cafemanha,txtcafemanha);
        teste(lanchemanha,txtlanchemanha);
        teste(almoco,txtalmoco);
        teste(lanchetarde,txtlanchetarde);
        teste(janta,txtjanta);
        teste(lanchenoite,txtlanchenoite);
    }

public void teste(String txtrefeicao, TextView refeicao){
        if(txtrefeicao.equals("Alimente-se")){
            refeicao.setText(txtrefeicao);
        }else {
            refeicao.setText(new StringBuilder().append(txtrefeicao).append(" kcal").toString());
        }
}
    public void refeicao(String refeicao, int idRefeicao){
        SharedPreferences preferences = getSharedPreferences(prefalimento, MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("REFEICAO", refeicao);
        editor.putInt("IDREFEICAO", idRefeicao);
        editor.putString("DATABANCO", dataagua);
        editor.commit();
    }
}
