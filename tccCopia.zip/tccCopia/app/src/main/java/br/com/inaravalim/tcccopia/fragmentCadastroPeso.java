package br.com.inaravalim.tcccopia;

import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

/**
 * A simple {@link Fragment} subclass.
 */
public class fragmentCadastroPeso extends Fragment {

    FloatingActionButton btnpeso;
    EditText editpesocad;
    IrecebeDados mListener;//Comunicaçao entre fragments e activity

    public fragmentCadastroPeso() {
    }

    @Override
    public void onAttach(Context activity) {
        super.onAttach(activity);
        if (!(activity instanceof IrecebeDados)) {
            throw new RuntimeException("A activity deve implementar a iinterface");
        }
        mListener = (IrecebeDados) activity;//esse obj se torna o meio de comunicaçao
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_cadastro_peso, container, false);
        editpesocad = (EditText) v.findViewById(R.id.editpesocad);
        btnpeso = (FloatingActionButton) v.findViewById(R.id.btnproximopeso);
        //METODO ONCLICK
        btnpeso.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String pesocamp = editpesocad.getText().toString();
                if (!(pesocamp.isEmpty())) {
                    float peso = Float.parseFloat(String.valueOf(editpesocad.getText()));
                    mListener.onPeso(peso);
                    ///ABRIR PROXIMO FRAGEMENT
                    FragmentManager fm = getFragmentManager();
                    FragmentTransaction ft = fm.beginTransaction();
                    ft.setCustomAnimations(R.anim.slide_in_right, R.anim.slide_in_right);
                    ft.replace(R.id.fragmentos,new fragmentCadastroAltura());
                    ft.addToBackStack(null);
                    ft.commit();
                } else {
                    editpesocad.setError("O campo está em branco");
                   // Toast.makeText(getActivity().getApplicationContext(), "O campo está em branco ", Toast.LENGTH_LONG).show();
                }
            }
        });
        return (v);
    }
}