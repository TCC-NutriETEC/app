package br.com.inaravalim.tcccopia;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class dicasAdapter extends ArrayAdapter<Dicas> {
    private final Context context;
    private final ArrayList<Dicas> elementos;

    public dicasAdapter(Context context, ArrayList<Dicas> elementos) {
        super(context, R.layout.molde_dicas, elementos);
        this.context = context;
        this.elementos = elementos;
    }
//linha a linha
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.molde_dicas, parent, false);
        TextView indice =(TextView) rowView.findViewById(R.id.indicedica) ;
        TextView conteudo = (TextView) rowView.findViewById(R.id.conteudodica);
        indice.setText(elementos.get(position).getIndice());
        conteudo.setText(elementos.get(position).getConteudo());
        return rowView;
    }
}
