package br.com.inaravalim.tcccopia;

public class Sites {
    private String nome, link, conteudo;

   // public Sites(String nome, String link, String conteudo) {
     //   this.nome = nome;
       // this.link = link;
       // this.conteudo = conteudo;
    //}

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getConteudo() {
        return conteudo;
    }

    public void setConteudo(String conteudo) {
        this.conteudo = conteudo;
    }
}
