package br.com.inaravalim.tcccopia;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;

public class MainCadastro extends FragmentActivity implements IrecebeDados {
    String nomecad, dataNas, emailcad, senhacad;
    Float pesocad;
    int alturacad, sexocad, idadecad;
    private String HOST = "https://tccnutriinfo.000webhostapp.com";

    public MainCadastro() {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_cadastro);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);//full screen
        //ADD FRAGMENTO INICIAL
        if (savedInstanceState == null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .add(R.id.fragmentos, new fragmentCadastroNome())
                    .commit();
        }
    }// FIM ONCREATE

    @Override
    public void onNome(String texto) {
        nomecad = texto;
        //Toast.makeText(MainCadastro.this, "Nome: " + texto, Toast.LENGTH_LONG).show();
    }

    @Override
    public void onPeso(float texto) {
        pesocad = texto;
    }

    @Override
    public void onData(int ano, int mes, int dia, int idade) {
        dataNas = new StringBuilder().append(ano).append("-").append(mes).append("-").append(dia).toString();
        idadecad = idade;
    }

    @Override
    public void onAltura(int texto) {
        alturacad = texto;
    }

    @Override
    public void onSexo(int texto) {
        sexocad = texto;
    }

    @Override
    public void onEmailonSenha(String emailL, String senhaL) {
        emailcad = emailL;
        senhacad = senhaL;
        cadastrar(nomecad, pesocad, dataNas, alturacad, sexocad, emailcad, senhacad, idadecad);
    }

    private void cadastrar(String nomeR, float pesoR, String dataR, int alturaR, int sexoR, String emailR, String senhaR,
                           int idadeR) {
        String URL = HOST + "/createusuario.php";

        Ion.with(MainCadastro.this)
                .load(URL)
                //PARAMETROS A SER PASSADOS
                .setBodyParameter("nome", nomeR)
                .setBodyParameter("peso", String.valueOf(pesoR))
                .setBodyParameter("altura", String.valueOf(alturaR))
                .setBodyParameter("datanasc", dataR)
                .setBodyParameter("email", emailR)
                .setBodyParameter("senha", senhaR)
                .setBodyParameter("sexo", String.valueOf(sexoR))
                .setBodyParameter("idade", String.valueOf(idadeR))
                .asJsonObject()
                .setCallback(new FutureCallback<JsonObject>() {
                    @Override
                    public void onCompleted(Exception e, JsonObject result) {

                        try {
                            String RETORNO = result.get("CREATE").getAsString();
                            if (RETORNO.equals("ERRO")) {
                                Toast.makeText(MainCadastro.this, "Ops, nao foi executado ", Toast.LENGTH_LONG).show();
                            } else if (RETORNO.equals("OK")) {
                                Intent intent = new Intent(MainCadastro.this, MainIntroducao.class);
                                startActivity(intent);
                            } else {
                                Toast.makeText(MainCadastro.this, "Nem entrou na condição ", Toast.LENGTH_LONG).show();
                            }
                        } catch (Exception erro) {
                            Toast.makeText(MainCadastro.this, "ERRO: " + erro, Toast.LENGTH_LONG).show();
                        }//FIM CATCH
                    }
                });
    }
}