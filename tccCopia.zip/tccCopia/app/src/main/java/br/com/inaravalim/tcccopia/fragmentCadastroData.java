package br.com.inaravalim.tcccopia;

import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Toast;

import java.util.Calendar;

/**
 * A simple {@link Fragment} subclass.
 */
public class fragmentCadastroData extends Fragment {

    private DatePicker data;
    private FloatingActionButton btndata;
    IrecebeDados mListener;//Comunicaçao entre fragments e activity

    public fragmentCadastroData() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(Context activity) {
        super.onAttach(activity);
        if (!(activity instanceof IrecebeDados)) {
            throw new RuntimeException("A activity deve implementar a iinterface");
        }
        mListener = (IrecebeDados) activity;
        //esse obj se torna o meio de comunicaçao
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_cadastro_data, container, false);
        data = (DatePicker) v.findViewById(R.id.datapicker);
        btndata = (FloatingActionButton) v.findViewById(R.id.btnproximodata);
        Toast.makeText(getActivity().getApplicationContext(), "Selecione sua data de nascimento ", Toast.LENGTH_LONG).show();

        btndata.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int mesAndroid = data.getMonth();
                int dia = data.getDayOfMonth();
                int ano = data.getYear();
                int mes = mesAndroid + 1;
                Calendar c = Calendar.getInstance();
                int diaAtual = c.get(Calendar.DAY_OF_MONTH);
                int mesAtual = c.get(Calendar.MONTH);
                int anoAtual = c.get(Calendar.YEAR);

                int idade = anoAtual - ano;
                if (mesAndroid > mesAtual) {
                    idade--;
                } else if (mesAtual == mesAndroid) {
                    if (dia > diaAtual) {
                        idade--;
                    }
                }
                if (idade<= 0) {
                    Toast.makeText(getActivity().getApplicationContext(), "Insira uma data de nascimento válida ", Toast.LENGTH_LONG).show();
                } else {
                    mListener.onData(ano, mes, dia, idade);
                    ///ABRIR PROXIMO FRAGEMENT
                    FragmentManager fm = getFragmentManager();
                    FragmentTransaction ft = fm.beginTransaction();
                    ft.setCustomAnimations(R.anim.slide_in_right, R.anim.slide_in_right);
                    ft.replace(R.id.fragmentos, new fragmentCadastroEmaileSenha(), "fim");
                    ft.addToBackStack(null);
                    ft.commit();
                }
            }
        });
        return (v);
    }
}