package br.com.inaravalim.tcccopia;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Layout;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class MainIntroducao extends AppCompatActivity {
    private ImageView logoIntroducao;
    private LinearLayout layoutbotao;
    private Button btnLogarIntroducao, btnCadastrarIntroducao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_introducao);
        //INDENTIFICANDO OBJETOS
        btnCadastrarIntroducao = (Button) findViewById(R.id.btncadastrarIntroducao);
        btnLogarIntroducao = (Button) findViewById(R.id.btnlogarIntroducao);
        logoIntroducao = (ImageView) findViewById(R.id.logoIntroducao);
        layoutbotao = (LinearLayout) findViewById(R.id.layoutbotao);
        getSupportActionBar().hide();//nao aparecer menu
        //MEXER A IMAGEM
        Animation desloca = new TranslateAnimation(0, 0, 0, -200);
        desloca.setFillAfter(true);
        desloca.setDuration(1500);
        logoIntroducao.startAnimation(desloca);
        //  APARECE BOTOES
        layoutbotao.setVisibility(View.VISIBLE);
        ObjectAnimator anim = ObjectAnimator.ofFloat(layoutbotao, "alpha", 0f, 1f);
        anim.setDuration(5000);
        anim.start();
        btnLogarIntroducao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainIntroducao.this, MainLogin.class);
                startActivity(intent);
            }
        });//FIM METODO CLIQUE LOGIN

        btnCadastrarIntroducao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainIntroducao.this, MainCadastro.class);
                startActivity(intent);
            }
        });//FIM METODO CLIQUE CADASTRO
    }//FIM ON CREATE
}//FIM CLASSE JAVA