package br.com.inaravalim.tcccopia;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;

public class MainAgua extends AppCompatActivity {
    private ImageView copo1, copo2, copo3, copo4, copo5, copo6, copo7, copo8, copo9, copo10, copo11, copo12;
    private int c1 = 0, c2 = 0, c3 = 0, c4 = 0, c5 = 0, c6 = 0, c7 = 0, c8 = 0, c9 = 0, c10 = 0, c11 = 0, c12 = 0;
    private int aguadia, quantcopos = 0;
    private String prefagua = "agua";
    private String pref = "preferencia";
    private String HOST = "https://tccnutriinfo.000webhostapp.com";

    //0=cinza 1=azul
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_agua);
        getSupportActionBar().hide();//nao aparecer menu
        //MEXER A IMAGEM
        copo1 = (ImageView) findViewById(R.id.copo1);
        copo2 = (ImageView) findViewById(R.id.copo2);
        copo3 = (ImageView) findViewById(R.id.copo3);
        copo4 = (ImageView) findViewById(R.id.copo4);
        copo5 = (ImageView) findViewById(R.id.copo5);
        copo6 = (ImageView) findViewById(R.id.copo6);
        copo7 = (ImageView) findViewById(R.id.copo7);
        copo8 = (ImageView) findViewById(R.id.copo8);
        copo9 = (ImageView) findViewById(R.id.copo9);
        copo10 = (ImageView) findViewById(R.id.copo10);
        copo11 = (ImageView) findViewById(R.id.copo11);
        copo12 = (ImageView) findViewById(R.id.copo12);
        copo1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (c1 == 0) {
                    atualizacopoazul(copo1);
                    c1 = 1;
                } else {
                    atualizacopocinza(copo1);
                    c1 = 0;
                }
                atualizaAgua();
            }
        });
        copo2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (c2 == 0) {
                    atualizacopoazul(copo2);
                    c2 = 1;
                } else {
                    atualizacopocinza(copo2);
                    c2 = 0;
                }
                atualizaAgua();
            }
        });
        copo3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (c3 == 0) {
                    atualizacopoazul(copo3);
                    c3 = 1;
                } else {
                    atualizacopocinza(copo3);
                    c3 = 0;
                }
                atualizaAgua();
            }
        });
        copo4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (c4 == 0) {
                    atualizacopoazul(copo4);
                    c4 = 1;
                } else {
                    atualizacopocinza(copo4);
                    c4 = 0;
                }
                atualizaAgua();
            }
        });
        copo5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (c5 == 0) {
                    atualizacopoazul(copo5);
                    c5 = 1;
                } else {
                    atualizacopocinza(copo5);
                    c5 = 0;
                }
                atualizaAgua();
            }
        });
        copo6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (c6 == 0) {
                    atualizacopoazul(copo6);
                    c6 = 1;
                } else {
                    atualizacopocinza(copo6);
                    c6 = 0;
                }
                atualizaAgua();
            }
        });
        copo7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (c7 == 0) {
                    atualizacopoazul(copo7);
                    c7 = 1;
                } else {
                    atualizacopocinza(copo7);
                    c7 = 0;
                }
                atualizaAgua();
            }
        });
        copo8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (c8 == 0) {
                    atualizacopoazul(copo8);
                    c8 = 1;
                } else {
                    atualizacopocinza(copo8);
                    c8 = 0;
                }
                atualizaAgua();
            }
        });
        copo9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (c9 == 0) {
                    atualizacopoazul(copo9);
                    c9 = 1;
                } else {
                    atualizacopocinza(copo9);
                    c9 = 0;
                }
                atualizaAgua();
            }
        });
        copo10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (c10 == 0) {
                    atualizacopoazul(copo10);
                    c10 = 1;
                } else {
                    atualizacopocinza(copo10);
                    c10 = 0;
                }
                atualizaAgua();
            }
        });
        copo11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (c11 == 0) {
                    atualizacopoazul(copo11);
                    c11 = 1;
                } else {
                    atualizacopocinza(copo11);
                    c11 = 0;
                }
                atualizaAgua();
            }
        });
        copo12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (c12 == 0) {
                    atualizacopoazul(copo12);
                    c12 = 1;
                } else {
                    atualizacopocinza(copo12);
                    c12 = 0;
                }
                atualizaAgua();
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        SharedPreferences preferences = getSharedPreferences(prefagua, MODE_PRIVATE);
        quantcopos = preferences.getInt("AGUA", 0)/200;
        //quantcopos = preferences.getInt("COPOS", 0);
        switch (quantcopos) {
            case 1:
                atualizacopoazul(copo1);
                c1 = 1;
                break;
            case 2:
                atualizacopoazul(copo1);
                c1 = 1;
                atualizacopoazul(copo2);
                c2 = 1;
                break;
            case 3:
                atualizacopoazul(copo1);
                c1 = 1;
                atualizacopoazul(copo2);
                c2 = 1;
                atualizacopoazul(copo3);
                c3 = 1;
                break;
            case 4:
                atualizacopoazul(copo1);
                c1 = 1;
                atualizacopoazul(copo2);
                c2 = 1;
                atualizacopoazul(copo3);
                c3 = 1;
                atualizacopoazul(copo4);
                c4 = 1;
                break;
            case 5:
                atualizacopoazul(copo1);
                c1 = 1;
                atualizacopoazul(copo2);
                c2 = 1;
                atualizacopoazul(copo3);
                c3 = 1;
                atualizacopoazul(copo4);
                c4 = 1;
                atualizacopoazul(copo5);
                c5 = 1;
                break;
            case 6:
                atualizacopoazul(copo1);
                c1 = 1;
                atualizacopoazul(copo2);
                c2 = 1;
                atualizacopoazul(copo3);
                c3 = 1;
                atualizacopoazul(copo4);
                c4 = 1;
                atualizacopoazul(copo5);
                c5 = 1;
                atualizacopoazul(copo6);
                c6 = 1;
                break;
            case 7:
                atualizacopoazul(copo1);
                c1 = 1;
                atualizacopoazul(copo2);
                c2 = 1;
                atualizacopoazul(copo3);
                c3 = 1;
                atualizacopoazul(copo4);
                c4 = 1;
                atualizacopoazul(copo5);
                c5 = 1;
                atualizacopoazul(copo6);
                c6 = 1;
                atualizacopoazul(copo7);
                c7 = 1;
                break;
            case 8:
                atualizacopoazul(copo1);
                c1 = 1;
                atualizacopoazul(copo2);
                c2 = 1;
                atualizacopoazul(copo3);
                c3 = 1;
                atualizacopoazul(copo4);
                c4 = 1;
                atualizacopoazul(copo5);
                c5 = 1;
                atualizacopoazul(copo6);
                c6 = 1;
                atualizacopoazul(copo7);
                c7 = 1;
                atualizacopoazul(copo8);
                c8 = 1;
                break;
            case 9:
                atualizacopoazul(copo1);
                c1 = 1;
                atualizacopoazul(copo2);
                c2 = 1;
                atualizacopoazul(copo3);
                c3 = 1;
                atualizacopoazul(copo4);
                c4 = 1;
                atualizacopoazul(copo5);
                c5 = 1;
                atualizacopoazul(copo6);
                c6 = 1;
                atualizacopoazul(copo7);
                c7 = 1;
                atualizacopoazul(copo8);
                c8 = 1;
                atualizacopoazul(copo9);
                c9 = 1;
                break;
            case 10:
                atualizacopoazul(copo1);
                c1 = 1;
                atualizacopoazul(copo2);
                c2 = 1;
                atualizacopoazul(copo3);
                c3 = 1;
                atualizacopoazul(copo4);
                c4 = 1;
                atualizacopoazul(copo5);
                c5 = 1;
                atualizacopoazul(copo6);
                c6 = 1;
                atualizacopoazul(copo7);
                c7 = 1;
                atualizacopoazul(copo8);
                c8 = 1;
                atualizacopoazul(copo9);
                c9 = 1;
                atualizacopoazul(copo10);
                c10 = 1;
                break;
            case 11:
                atualizacopoazul(copo1);
                c1 = 1;
                atualizacopoazul(copo2);
                c2 = 1;
                atualizacopoazul(copo3);
                c3 = 1;
                atualizacopoazul(copo4);
                c4 = 1;
                atualizacopoazul(copo5);
                c5 = 1;
                atualizacopoazul(copo6);
                c6 = 1;
                atualizacopoazul(copo7);
                c7 = 1;
                atualizacopoazul(copo8);
                c8 = 1;
                atualizacopoazul(copo9);
                c9 = 1;
                atualizacopoazul(copo10);
                c10 = 1;
                atualizacopoazul(copo11);
                c11 = 1;
                break;
            case 12:
                atualizacopoazul(copo1);
                c1 = 1;
                atualizacopoazul(copo2);
                c2 = 1;
                atualizacopoazul(copo3);
                c3 = 1;
                atualizacopoazul(copo4);
                c4 = 1;
                atualizacopoazul(copo5);
                c5 = 1;
                atualizacopoazul(copo6);
                c6 = 1;
                atualizacopoazul(copo7);
                c7 = 1;
                atualizacopoazul(copo8);
                c8 = 1;
                atualizacopoazul(copo9);
                c9 = 1;
                atualizacopoazul(copo10);
                c10 = 1;
                atualizacopoazul(copo11);
                c11 = 1;
                atualizacopoazul(copo12);
                c12 = 1;
                break;
        }

    }

    public void atualizacopoazul(ImageView copo) {
        copo.setImageResource(R.drawable.copoazul);
    }

    public void atualizacopocinza(ImageView copo) {
        copo.setImageResource(R.drawable.copocinza);
    }

    public void atualizaAgua() {
        quantcopos = c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12;
        aguadia = quantcopos * 200;
        SharedPreferences preferences = getSharedPreferences(prefagua, MODE_PRIVATE);
       // SharedPreferences.Editor editor = preferences.edit();
       // editor.putInt("COPOS", quantcopos);
        //editor.commit();
        final String data = preferences.getString("DATA", "vazio");
        SharedPreferences preference = getSharedPreferences(pref, MODE_PRIVATE);
        final int id = preference.getInt("ID", 0);
        Toast.makeText(MainAgua.this, "" + aguadia+ " ml consumidos", Toast.LENGTH_SHORT).show();
        String url = HOST + "/updateagua.php";
        Ion.with(MainAgua.this)
                .load(url)
                .setBodyParameter("agua", String.valueOf(aguadia))
                .setBodyParameter("idusuario", String.valueOf(id))
                .setBodyParameter("dataatual", data)
                .asJsonObject()
                .setCallback(new FutureCallback<JsonObject>() {
                    @Override
                    public void onCompleted(Exception e, JsonObject result) {
                        if (result.get("UPDATE").getAsString().equals("OK")) {
                            SharedPreferences preferences = getSharedPreferences(prefagua, MODE_PRIVATE);
                            SharedPreferences.Editor editor = preferences.edit();
                            editor.clear().commit();
                            atualizaPreferencia(aguadia, id, data);
                        } else {
                            Toast.makeText(MainAgua.this,
                                    "Ocorreu um erro ao atualizar ",
                                    Toast.LENGTH_LONG).show();
                        }
                    }
                });
    }

    public void atualizaPreferencia(int quantagua, int idusuario, String dataagua) {
        SharedPreferences preferences = getSharedPreferences(prefagua, MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("DATA", dataagua);
        editor.putInt("AGUA", quantagua);
        editor.putInt("ID", idusuario);
        editor.putInt("COPOS", quantcopos);
        editor.commit();
    }
}
