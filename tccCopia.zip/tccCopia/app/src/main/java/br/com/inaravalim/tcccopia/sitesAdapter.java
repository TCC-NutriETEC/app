package br.com.inaravalim.tcccopia;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import java.util.ArrayList;

public class sitesAdapter extends ArrayAdapter<Sites> {
    private final Context context;
    private final ArrayList<Sites> elementos;

    public sitesAdapter(Context context, ArrayList<Sites> elementos) {
        super(context, R.layout.molde_sites, elementos);
        this.context = context;
        this.elementos = elementos;
    }
//linha a linha
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.molde_sites, parent, false);
        TextView nome =(TextView) rowView.findViewById(R.id.nomesite) ;
        TextView link = (TextView) rowView.findViewById(R.id.link);
        TextView conteudo = (TextView) rowView.findViewById(R.id.conteudo);
        nome.setText(elementos.get(position).getNome());
        link.setText(elementos.get(position).getLink());
        conteudo.setText(elementos.get(position).getConteudo());
        return rowView;
    }
}
