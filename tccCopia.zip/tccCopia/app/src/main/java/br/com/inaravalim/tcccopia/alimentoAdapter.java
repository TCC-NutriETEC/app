package br.com.inaravalim.tcccopia;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class alimentoAdapter extends ArrayAdapter<Alimento> {
    private final Context context;
    private final ArrayList<Alimento> elementos;

    public alimentoAdapter(Context context, ArrayList<Alimento> elementos) {
        super(context, R.layout.molde_alimento, elementos);
        this.context = context;
        this.elementos = elementos;
    }
//linha a linha
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.molde_alimento, parent, false);
        TextView nomeAlimento =(TextView) rowView.findViewById(R.id.nomealimento) ;
        nomeAlimento.setText(elementos.get(position).getNomeAlimento());
        return rowView;
    }
}
