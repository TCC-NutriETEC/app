package br.com.inaravalim.tcccopia;


import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;


/**
 * A simple {@link Fragment} subclass.
 */
public class fragmentCadastroEmaileSenha extends Fragment {
    FloatingActionButton btnemailesenha;
    EditText editemailcad;
    EditText editsenhacad;
    IrecebeDados mListener;//Comunicaçao entre fragments e activity

    public fragmentCadastroEmaileSenha() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(Context activity) {
        super.onAttach(activity);
        if (!(activity instanceof IrecebeDados)) {
            throw new RuntimeException("A activity deve implementar a iinterface");
        }
        mListener = (IrecebeDados) activity;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v= inflater.inflate(R.layout.fragment_cadastro_email_senha, container, false);
        editemailcad = (EditText) v.findViewById(R.id.editemailcad);
        editsenhacad = (EditText) v.findViewById(R.id.editsenhacad);
        btnemailesenha = (FloatingActionButton) v.findViewById(R.id.btnproximoemailesenha);
        btnemailesenha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = editemailcad.getText().toString() ;
                String senha = editsenhacad.getText().toString() ;
                if (!(email.isEmpty())||!(senha.isEmpty())) {
                   mListener.onEmailonSenha(email,senha);
                }else{
                    Toast.makeText(getActivity().getApplicationContext(), "Há campos em brancos. ", Toast.LENGTH_LONG).show();
                }
            }
        });
        return (v);
    }
}
