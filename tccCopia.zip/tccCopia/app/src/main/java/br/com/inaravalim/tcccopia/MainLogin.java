package br.com.inaravalim.tcccopia;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;

public class MainLogin extends AppCompatActivity {
    private String pref = "preferencia";
    private EditText editEmailLog, editSenhaLog;
    private Button btnLogar;
    private String email, senha;
    private String HOST = "https://tccnutriinfo.000webhostapp.com";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_login);
        //ACHANDO ELEMENTOS PELO ID
        editEmailLog = (EditText) findViewById(R.id.editEmailLog);
        editSenhaLog = (EditText) findViewById(R.id.editSenhaLog);
        btnLogar = (Button) findViewById(R.id.btnLogar);
        //BOTAO LOGAR
        btnLogar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //TRANSFORMA EM STRING
                email = editEmailLog.getText().toString();
                senha = editSenhaLog.getText().toString();
                String URL = HOST + "/login.php";
                if (!(email.isEmpty() || senha.isEmpty())) {
                    Ion.with(MainLogin.this)
                            .load(URL)
                            //PARAMETROS A SER PASSADOS
                            .setBodyParameter("email_app", email)
                            .setBodyParameter("senha_app", senha)
                            .asJsonObject()
                            .setCallback(new FutureCallback<JsonObject>() {
                                @Override
                                public void onCompleted(Exception e, JsonObject result) {
                                    try {
                                        String RETORNO = result.get("LOGIN").getAsString();

                                        if (RETORNO.equals("ERRO")) {
                                            Toast.makeText(MainLogin.this, "Ops, email ou senha incorretos ", Toast.LENGTH_LONG).show();
                                        } else if (RETORNO.equals("SUCESSO")) {
                                            SharedPreferences preferences = getSharedPreferences(pref, MODE_PRIVATE);
                                            SharedPreferences.Editor editor = preferences.edit();
                                            editor.putString("EMAIL", email);
                                            editor.putInt("LOGADO", 1);
                                            editor.commit();
                                            Intent abrePrincipal = new Intent(MainLogin.this, SplashReceberDados.class);
                                            startActivity(abrePrincipal);
                                            finish();
                                        } else {
                                            Toast.makeText(MainLogin.this, "Nem entrou na condição ", Toast.LENGTH_LONG).show();
                                        }
                                    } catch (Exception erro) {
                                        Toast.makeText(MainLogin.this, "ERRO: " + erro, Toast.LENGTH_LONG).show();
                                    }//FIM CATCH
                                }
                            });//FUTURE CALLBACK
                } else {
                    if (email.isEmpty() & senha.isEmpty()) {
                        editEmailLog.setError("Campo esta em branco");
                        editEmailLog.setFocusable(true);
                    } else {
                        if (email.isEmpty()) {
                            editEmailLog.setError("Campo esta em branco");
                            editEmailLog.setFocusable(true);
                        } else {
                            editSenhaLog.setError("Campo esta em branco");
                            editSenhaLog.setFocusable(true);
                        }
                    }
                }//FIM ELSE
            }// FIM ONCLICK
        });//FIM BOTAO LOGAR
    }// FIM ONCREATE
}// FIM CLASSE
