package br.com.inaravalim.tcccopia;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.Objects;

public class MainUsuario extends AppCompatActivity {

    private EditText editNome, editEmail, editSenha, editData;
    private ImageButton btnFemi, btnMasc;
    private Button btnAlterar;
    private String pref = "preferencia";
    public int sexoAltera;
    public int sexo;
    private Calendar mycalendar;
    private String HOST = "https://tccnutriinfo.000webhostapp.com";
    private Snackbar atualiza;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_usuario);
        Objects.requireNonNull(getSupportActionBar()).hide();//nao aparecer menu
        editNome = (EditText) findViewById(R.id.editnome);
        editEmail = (EditText) findViewById(R.id.editemail);
        editSenha = (EditText) findViewById(R.id.editsenha);
        editData = (EditText) findViewById(R.id.data);
        btnFemi = (ImageButton) findViewById(R.id.feminino);
        btnMasc = (ImageButton) findViewById(R.id.masculino);
        btnAlterar = (Button) findViewById(R.id.botaoalterar);
        SharedPreferences preferences = getSharedPreferences(pref, MODE_PRIVATE);
        String nome = preferences.getString("NOME", "vazio");
        String email = preferences.getString("EMAIL", "vazio");
        String data = preferences.getString("DATANASC", "vazio");
        String senha = preferences.getString("SENHA", "vazio");
        sexo = preferences.getInt("SEXO", 2);
        if (sexo==1){
            sexo(1, btnFemi, btnMasc);
        }
        if (sexo==0){
            sexo(0, btnMasc, btnFemi);
        }
        String anocru = data.substring(0, 4);
        String mescru = data.substring(5, 7);
        String diacru = data.substring(8, 10);
        String datacru = new StringBuilder().append(diacru).append("/").append(mescru).append("/").append(anocru).toString();
        editNome.setText(nome);
        editSenha.setText(senha);
        editEmail.setText(email);
        editData.setText(datacru);
        mycalendar = Calendar.getInstance();
        final DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthofYear, int dayofmonth) {
                mycalendar.set(Calendar.YEAR, year);
                mycalendar.set(Calendar.MONTH, monthofYear);
                mycalendar.set(Calendar.DAY_OF_MONTH, dayofmonth);
                updateLabel();
            }
        };
        btnMasc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sexo(0, btnMasc, btnFemi);
            }
        });
        btnFemi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sexo(1, btnFemi, btnMasc);
            }
        });
        btnAlterar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nomeAlterado = editNome.getText().toString();
                String senhaAlterada = editSenha.getText().toString();
                String emailAlterado = editEmail.getText().toString();
                String datainteira = editData.getText().toString();
                String dia = datainteira.substring(0, 2);
                String mes = datainteira.substring(3, 5);
                String ano = datainteira.substring(6, 10);
                String dataAlterada = new StringBuilder().append(ano).append("-").append(mes).append("-").append(dia).toString();
                atualiza= Snackbar.make(view,"Dados Atualizados",Snackbar.LENGTH_LONG);
                atualizarDados(nomeAlterado, senhaAlterada, emailAlterado, dataAlterada, sexoAltera);
            }
        });
        editData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog(MainUsuario.this, date, mycalendar.get(Calendar.YEAR), mycalendar.get(Calendar.MONTH), mycalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });
    }

    public void sexo(int sexo, ImageButton botaoSexo, ImageButton botaoDesativado) {
        sexoAltera = sexo;
        botaoSexo.setBackgroundColor(getResources().getColor(R.color.colorPrimaryLight));
        botaoDesativado.getBackground().setAlpha(0);
    }

    public void updateLabel() {
        String myFormat = "dd/MM/yyyy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        editData.setText(sdf.format(mycalendar.getTime()));
    }

    public void atualizarDados(String nomeAlterado, String senhaAlterada, final String emailAlterado, String dataAlterada, int sexoAlterado) {
        SharedPreferences preferences = getSharedPreferences(pref, MODE_PRIVATE);
        int id = preferences.getInt("ID", 0);
        String url = HOST + "/updateusuario.php";
        Ion.with(MainUsuario.this)
                .load(url)
                .setBodyParameter("nome", nomeAlterado)
                .setBodyParameter("senha", senhaAlterada)
                .setBodyParameter("email", emailAlterado)
                .setBodyParameter("datanasc", dataAlterada)
                .setBodyParameter("sexo", String.valueOf(sexoAlterado))
                .setBodyParameter("id", String.valueOf(id))
                .asJsonObject()
                .setCallback(new FutureCallback<JsonObject>() {
                    @Override
                    public void onCompleted(Exception e, JsonObject result) {
                        if (result.get("UPDATE").getAsString().equals("OK")) {
                            SharedPreferences preferences = getSharedPreferences(pref, MODE_PRIVATE);
                            SharedPreferences.Editor editor = preferences.edit();
                            editor.clear().commit();
                            atualizaPreferencia(emailAlterado);
                            atualiza.show();
                        } else {
                            Toast.makeText(MainUsuario.this,
                                    "Ocorreu um erro ao atualizar ",
                                    Toast.LENGTH_LONG).show();
                        }
                    }
                });

    }
    public void atualizaPreferencia(final String emailpassado){
        String url = HOST + "/dadosusuarios.php";
        //RECEBER DADOS
        Ion.with(MainUsuario.this)
                .load(url)
                .setBodyParameter("email", emailpassado)
                .asJsonObject()
                .setCallback(new FutureCallback<JsonObject>() {
                    @Override
                    public void onCompleted(Exception e, JsonObject result) {
                        String nome = result.get("NOME").getAsString();
                        String senha = result.get("SENHA").getAsString();
                        float peso = result.get("PESO").getAsFloat();
                        int altura = result.get("ALTURA").getAsInt();
                        String data_nascimento = result.get("DATANASC").getAsString();
                        float caloria = result.get("CALORIA").getAsFloat();
                        float proteina = result.get("PROTEINA").getAsFloat();
                        float carboidrato = result.get("CARBOIDRATO").getAsFloat();
                        int id = result.get("ID").getAsInt();
                        int sexoult=result.get("SEXO").getAsInt();
                        SharedPreferences preferences = getSharedPreferences(pref, MODE_PRIVATE);
                        SharedPreferences.Editor editor = preferences.edit();
                        editor.putInt("LOGADO", 1);
                        editor.putInt("ID", id);
                        editor.putString("EMAIL", emailpassado);
                        editor.putString("NOME", nome);
                        editor.putFloat("PESO", peso);
                        editor.putInt("ALTURA", altura);
                        editor.putString("DATANASC", data_nascimento);
                        editor.putFloat("CALORIA", caloria);
                        editor.putFloat("PROTEINA", proteina);
                        editor.putFloat("CARBOIDRATO", carboidrato);
                        editor.putString("SENHA", senha);
                        editor.putInt("SEXO", sexoult);
                        editor.commit();
                    }
                });
    }
}
