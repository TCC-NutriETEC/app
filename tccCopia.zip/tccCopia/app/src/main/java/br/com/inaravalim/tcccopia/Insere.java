package br.com.inaravalim.tcccopia;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.PopupMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;

public class Insere extends AppCompatActivity implements PopupMenu.OnMenuItemClickListener {
    private String prefalimento = "alimento", alimento, refeicao,pref = "preferencia";
    private TextView txtAlimento, txtrefeicao, txtunidade, txtquantidade, txtproteina, txtcarboidrato, txtcalorias;
    private EditText editquantidade, editunidade;
    private ImageButton pesquisar;
    private int idunidade;
    private Button btninsere;
    private String HOST = "https://tccnutriinfo.000webhostapp.com";
    String idalimentacao,idalimento,modo_preparacao,unidadebanco,caloria,proteina,carboidrato;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insere);
        btninsere=(Button) findViewById(R.id.btninsere);
        txtAlimento = (TextView) findViewById(R.id.txtalimento);
        editquantidade = (EditText) findViewById(R.id.editquantidade);
        editunidade = (EditText) findViewById(R.id.editunidade);
        pesquisar=(ImageButton) findViewById(R.id.pesquisarInformacao);
        //TABELA
        txtrefeicao = (TextView) findViewById(R.id.txtrefeicaoinsere);
        txtunidade = (TextView) findViewById(R.id.txtunidadeinsere);
        txtquantidade = (TextView) findViewById(R.id.txtquantidadeinsere);
        txtproteina = (TextView) findViewById(R.id.txtproteina);
        txtcarboidrato = (TextView) findViewById(R.id.txtcarboidrato);
        txtcalorias = (TextView) findViewById(R.id.txtcaloriasinsere);
        SharedPreferences preferences = getSharedPreferences(prefalimento, MODE_PRIVATE);
        alimento = preferences.getString("NOME_ALIMENTO", "vazio");
        refeicao = preferences.getString("REFEICAO", "vazio");
        atualizarAlimento();
        btninsere.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                inserirAlimento();
            }
        });
        editunidade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showPopup(view);
            }
        });
        pesquisar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pesquisarInformacao();
            }
        });
    }
    private void pesquisarInformacao() {
        String quantidade =editquantidade.getText().toString();

        String url = HOST + "/pesquisaralimento.php";
        //RECEBER DADOS
        Ion.with(Insere.this)
                .load(url)
                .setBodyParameter("modo", modo_preparacao)
                .setBodyParameter("unidade", String.valueOf(idunidade))
                .setBodyParameter("idalimento", idalimento)
                .setBodyParameter("quantidade", quantidade)
                .setBodyParameter("caloriaapp", caloria)
                .setBodyParameter("proteinaapp", proteina)
                .setBodyParameter("carboidratoapp", carboidrato)
                .asJsonObject()
                .setCallback(new FutureCallback<JsonObject>() {
                    @Override
                    public void onCompleted(Exception e, JsonObject result) {
                        idalimentacao = result.get("IDALIMENTACAO").getAsString();
                        caloria = result.get("CALORIA").getAsString();
                        proteina = result.get("PROTEINA").getAsString();
                        carboidrato = result.get("CARBOIDRATO").getAsString();
                        atualizarCampos(proteina, caloria, carboidrato);
                    }
                });
    }

    private void atualizarAlimento() {
        txtAlimento.setText(alimento);
        editquantidade.setText("100");
        editunidade.setText("Gramas");
        idunidade=16;
        atualizarTabela();
    }

    private void atualizarTabela() {
        String url = HOST + "/readalimento.php";
        //RECEBER DADOS
        Ion.with(Insere.this)
                .load(url)
                .setBodyParameter("alimento", alimento)
                .asJsonObject()
                .setCallback(new FutureCallback<JsonObject>() {
                    @Override
                    public void onCompleted(Exception e, JsonObject result) {
                        String nome = result.get("ALIMENTO").getAsString();
                         idalimento = result.get("IDALIMENTO").getAsString();
                         modo_preparacao = result.get("MODO").getAsString();
                         unidadebanco = result.get("UNIDADE").getAsString();
                         int grama = result.get("GRAMA").getAsInt();
                         caloria = result.get("CALORIA").getAsString();
                         proteina = result.get("PROTEINA").getAsString();
                         carboidrato = result.get("CARBOIDRATO").getAsString();
                        atualizarCampos(proteina, caloria, carboidrato);
                    }
                });
    }

    public void showPopup(View v) {
        PopupMenu popup = new PopupMenu(this, v);
        popup.setOnMenuItemClickListener(this);
        popup.inflate(R.menu.popup_menu);
        popup.show();
    }

    private void atualizarCampos(String proteina, String caloria, String carboidrato) {
        String unidade = editunidade.getText().toString();
        String quantidade = editquantidade.getText().toString();
        txtrefeicao.setText(refeicao);
        txtunidade.setText(unidade);
        txtquantidade.setText(new StringBuilder().append(quantidade).append(" gramas").toString());
        txtproteina.setText(new StringBuilder().append(proteina).append(" gramas").toString());
        txtcalorias.setText(new StringBuilder().append(caloria).append(" kcal").toString());
        txtcarboidrato.setText(new StringBuilder().append(carboidrato).append(" gramas").toString());
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public boolean onMenuItemClick(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.grama:
                idunidade = 16;
                editunidade.setText("Grama");
                return true;
            case R.id.unidade:
                idunidade = 14;
                editunidade.setText("Unidade");
                return true;
            case R.id.colher:
                idunidade = 5;
                editunidade.setText("Colher de sopa");
                return true;
            default:
                return false;
        }
    }

    public void inserirAlimento() {
        SharedPreferences preferencerefeicao = getSharedPreferences(prefalimento, MODE_PRIVATE);
        int refeicao = preferencerefeicao.getInt("IDREFEICAO", 0);
        String  databanco = preferencerefeicao.getString("DATABANCO", "");
        SharedPreferences preferenceusuario = getSharedPreferences(pref, MODE_PRIVATE);
        int id = preferenceusuario.getInt("ID", 0);
        String url = HOST + "/historico.php";
        Ion.with(Insere.this)
                .load(url)
                .setBodyParameter("dataatual", databanco)
                .setBodyParameter("idusuario", String.valueOf(id))
                .setBodyParameter("idalimentacao", idalimentacao)
                .setBodyParameter("idrefeicao", String.valueOf(refeicao))
                .asJsonObject()
                .setCallback(new FutureCallback<JsonObject>() {
                    @Override
                    public void onCompleted(Exception e, JsonObject result) {
                        String RETORNO = result.get("INSERT").getAsString();
                        if (RETORNO.equals("ERRO")) {
                            Toast.makeText(Insere.this, "Ops, nao foi executado ", Toast.LENGTH_LONG).show();
                        } else{
                            Toast.makeText(Insere.this, "a ", Toast.LENGTH_LONG).show();
                        }
                    }
                });
    }
}
