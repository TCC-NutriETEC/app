package br.com.inaravalim.tcccopia;

public class Alimento {
    private String nomeAlimento;

    public String getNomeAlimento() {
        return nomeAlimento;
    }

    public void setNomeAlimento(String nomeAlimento) {
        this.nomeAlimento = nomeAlimento;
    }

}
