package br.com.inaravalim.tcccopia;

import android.content.Intent;
import android.net.Uri;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;

import java.util.ArrayList;

public class MainSites extends AppCompatActivity {
    private String HOST = "https://tccnutriinfo.000webhostapp.com";
    private ArrayList<Sites> list;
    private sitesAdapter sitesAdapter;
    private TextView link;
    private ListView lista;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_sites);
        getSupportActionBar().hide();//nao aparecer menu
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);//full screen
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendEmail();
            }
        });
        list = new ArrayList<Sites>();
        lista = (ListView) findViewById(R.id.listadicas);
        sitesAdapter = new sitesAdapter(this, list);
        lista.setAdapter(sitesAdapter);
        adicionarSites();

        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String linkclicado = list.get(i).getLink();
                browser(linkclicado);
                Toast.makeText(MainSites.this, "Encaminhando para:" + list.get(i).getLink(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void browser(String linkparam) {
        Intent intentbrowser = new Intent(Intent.ACTION_VIEW, Uri.parse(linkparam));
        startActivity(intentbrowser);
    }

    private void adicionarSites() {
        String url = HOST + "/readsites.php";
        Ion.with(MainSites.this)
                .load(url)
                .asJsonArray()
                .setCallback(new FutureCallback<JsonArray>() {
                    @Override
                    public void onCompleted(Exception e, JsonArray result) {
                        for (int i = 0; i < result.size(); i++) {
                            JsonObject obj = result.get(i).getAsJsonObject();
                            Sites d = new Sites();

                            d.setNome(obj.get("NOME").getAsString());
                            d.setLink(obj.get("LINK").getAsString());
                            d.setConteudo(obj.get("CONTEUDO").getAsString());
                            list.add(d);
                        }
                        sitesAdapter.notifyDataSetChanged();
                    }
                });
    }

    public void sendEmail() {
        String[] TO = {"tcc.etec2018.nutri@gmail.com"};
        String[] CC = {""};
        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setData(Uri.parse("mailto:"));
        emailIntent.putExtra(Intent.EXTRA_EMAIL, TO);
        emailIntent.putExtra(Intent.EXTRA_CC, CC);
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Sugestão");
        emailIntent.putExtra(Intent.EXTRA_TEXT, "Escreva aqui sua sugestão para o aplicativo");
        emailIntent.setType("message/rfc822");
        try {
            startActivity(Intent.createChooser(emailIntent, "Enviar sugestão"));
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(MainSites.this, "Há um erro " + ex, Toast.LENGTH_LONG);
        }
    }
}
