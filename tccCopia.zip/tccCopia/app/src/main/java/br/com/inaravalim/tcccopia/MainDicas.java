package br.com.inaravalim.tcccopia;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;

import java.util.ArrayList;

public class MainDicas extends AppCompatActivity {
    private String HOST = "https://tccnutriinfo.000webhostapp.com";
    private ArrayList<Dicas> list;
    private dicasAdapter dicasAdapter;
    private ListView lista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_dicas);
        getSupportActionBar().hide();//nao aparecer menu
        list = new ArrayList<Dicas>();
        lista = (ListView) findViewById(R.id.listadicasverdadeiro);
        dicasAdapter = new dicasAdapter(this, list);
        lista.setAdapter(dicasAdapter);
        adicionarDicas();
    }

    private void adicionarDicas() {
        String url = HOST + "/readdicas.php";
        Ion.with(MainDicas.this)
                .load(url)
                .asJsonArray()
                .setCallback(new FutureCallback<JsonArray>() {
                    @Override
                    public void onCompleted(Exception e, JsonArray result) {
                        for (int i = 0; i < result.size(); i++) {
                            JsonObject obj = result.get(i).getAsJsonObject();
                            Dicas d = new Dicas();
                            int numero =i+1;
                            d.setIndice("#"+numero);
                            d.setConteudo(obj.get("CONTEUDO").getAsString());
                            list.add(d);
                        }
                        dicasAdapter.notifyDataSetChanged();
                    }
                });
    }
}
